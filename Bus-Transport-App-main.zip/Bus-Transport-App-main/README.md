# INTRODUCTION

Among all public transport services, bus transport service is one of the major means of 
transportation used by public on daily basis.Being a daily bus commutator, it becomes annoying 
to not know when the bus will arrive and wait for indefinite time. There are also circumstances when the bus changes its route and the user is clueless
of this change.There are many other problems like these which are overcome by a 
single app – ‘Bus Transport Application’.

## FEATURES

We have developed a complete Bus Transport application which have the following functionality:

Real time bus tracking

Geo fencing

Online ticket booking

Online schedules

Lost and Found Section

